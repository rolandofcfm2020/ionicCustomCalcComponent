import { Component, Input, OnInit } from '@angular/core';

interface INumbers 
{
  number1: number;
  number2: number;
}

@Component({
  selector: 'app-custom-calc',
  templateUrl: './custom-calc.component.html',
  styleUrls: ['./custom-calc.component.scss'],
})
export class CustomCalcComponent implements OnInit {

  myNumbers: INumbers;
  @Input()
  x: number;

  @Input()
  y: number;

  @Input()
  customTitle: string;

  constructor() { 
    
  }

  ngOnInit() {
    debugger;
    this.myNumbers = <INumbers>{};
    if (this.x !== undefined)
    this.myNumbers.number1 = this.x;

    if (this.y !== undefined)
    this.myNumbers.number2 = this.y;

    var w = this.customTitle;
  }

}
